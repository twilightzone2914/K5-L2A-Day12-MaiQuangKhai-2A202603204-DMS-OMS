# TEAM — Ngày 12

Mã bộ ảnh: **G02** · Hình thức: cá nhân (ghép cặp review chéo)

| Họ tên | MSSV | Đã gán đủ 22 ảnh? | Review chéo với (peer diff) | Số dòng disagreement đã xử lý |
|---|---|---|---|---|
| Mai Quang Khải | 2A202603204 | có | Hoàng Quốc Mạnh - 2A202603219 | 10 dòng (trong tổng 44 dòng diff) |

Ca hai bạn vẫn không thống nhất và đã hỏi coach (ghi tên ảnh + đối tượng):

- `S01_rgb.png` / `S02_rgb.png`: phân biệt ranh giới `infant_seat` vs `child_seat` trên một số góc nhìn SVIRO.

## Cá nhân

### MaiQuangKhai-2A202603204
- Phần mình làm: Tự gán đủ 22 ảnh cốt lõi (`G02`), chạy `cabin_check` ở các mốc `cpA`, `cpB`, `final`, chạy `diff` với bạn cùng mã `G02`, sửa lại các lỗi phát hiện sau review để ra `export_final_v2.zip` đạt `0 lỗi, 0 cảnh báo`, hoàn thiện `ir_log.csv`, `class_list_v0.md`, `self_review.md`, `exit_ticket.md`, `prompts.md`.
- Điều mình học được hôm nay: Hiểu rõ sự khác biệt giữa ảnh IR mô phỏng (SVIRO) và ảnh NIR thật (Drive&Act), quy ước gọi ghế theo xe (ngược chiều ảnh khi camera nhìn về sau), quy ước trái/phải theo người trên ảnh xoay 90°, và tầm quan trọng của việc không đoán (`unknown` / `occluded`) kèm đối chiếu chéo.
