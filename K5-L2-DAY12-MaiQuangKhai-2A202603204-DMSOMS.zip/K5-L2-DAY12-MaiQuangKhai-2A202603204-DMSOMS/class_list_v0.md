# Danh sách lớp v0 — Mai Quang Khải · G02

Viết tiếp từ slide 54 bài giảng. Mỗi lớp trả lời: **model cần nhận ra cái này để làm gì?**

## DMS (7 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng DMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | `face` (`eye_left`, `eye_right`) | `open` / `closed` / `unknown` | Phát hiện buồn ngủ, nhắm mắt kéo dài (PERCLOS) và cảnh báo mất tập trung | Có, trừ khi bị lóa đèn LED trên kính hoặc kính râm tối |
| 2 | `face` (`gaze_zone`) | `road` / `mirror_l` / `mirror_r` / `mirror_c` / `cluster` / `center` / `lap` / `other` | Xác định tài xế có đang nhìn đường hay liếc màn hình/điện thoại/gương | Có, dựa theo hướng đầu và vị trí đồng tử trong vùng sáng NIR |
| 3 | `face` (`glasses`) | `none` / `clear` / `sun` / `unknown` | Hiệu chỉnh độ tin cậy của model mắt/gaze (kính râm hoặc phản xạ làm giảm độ chính xác) | Có với gọng và phản xạ kính cận; kính râm trên NIR đôi khi trông gần trong suốt |
| 4 | `face13` | 13 điểm mặt (`occluded` / `outside`) | Ước lượng tư thế đầu (yaw/pitch/roll) và độ mở mắt chính xác theo từng điểm | Có, trừ các điểm bị tay, gọng kính hoặc góc quay che khuất |
| 5 | `hand` (`whose`, `side`, `on_wheel`) | `driver`/`passenger` · `left`/`right` · `yes`/`no`/`unknown` | Kiểm tra tài xế có giữ tay trên vô lăng hay đang buông tay/làm việc khác | Có, thấy rõ hình dạng bàn tay và vị trí tương đối với vô lăng |
| 6 | `phone` (`state`) | `held` / `mounted` / `lap` | Phát hiện hành vi cầm hoặc sử dụng điện thoại gây mất tập trung khi lái xe | Có (hình dạng máy, màn hình phát sáng), nhưng dễ nhầm với vật tối màu nếu bị ngón tay che |
| 7 | `person` (`seatbelt`) | `worn_correct` / `worn_incorrect` / `not_worn` / `unknown` | Cảnh báo tài xế chưa thắt dây an toàn hoặc thắt sai cách (luồn dưới nách/sau lưng) | Có nếu độ tương phản đủ, nhưng dễ bị mất trên áo tối màu trong vùng bóng |

## OMS (7 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng OMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | `person` (`seat`) | `driver` / `front_passenger` / `rear_left` / `rear_middle` / `rear_right` | Xác định vị trí có người ngồi để điều khiển cảnh báo dây an toàn và kích hoạt túi khí đúng ghế | Có (hình dạng người và vị trí ghế), dù mất thông tin màu quần áo |
| 2 | `person` (`seatbelt`) | `worn_correct` / `worn_incorrect` / `not_worn` / `unknown` | Nhắc thắt dây an toàn cho hành khách từng ghế | Có một phần ở vùng sáng; khó thấy nếu dây trùng màu với áo tối |
| 3 | `child_seat` (`seat`, `occupied`) | `seat` · `unknown` / `no` / `yes` | Phát hiện ghế trẻ em và trạng thái có trẻ ngồi để điều chỉnh túi khí và nhắc kiểm tra hàng ghế sau | Có (khung ghế lớn), nhưng phần lòng ghế tối dễ làm `occupied` thành `unknown` |
| 4 | `infant_seat` (`seat`, `facing`) | `seat` · `rear` / `front` | Nhận diện nôi em bé quay ngược/xuôi chiều để tắt túi khí ghế trước và bật cảnh báo bỏ quên trẻ | Có (hình dạng nôi xách đặc trưng) |
| 5 | `object` (`seat`, `type`) | `seat` · `bag` / `box` / `cup` / `other` | Phân biệt đồ vật đặt trên ghế với người ngồi để tránh báo giả cảm biến trọng lượng/nhắc quên đồ | Có về hình dạng/kích thước, nhưng mất chi tiết bề mặt và màu sắc |
| 6 | `face` (trên OMS) | box mặt người lớn | Hỗ trợ xác định hướng ngồi, nhận diện người lớn và phân biệt với đồ vật cồng kềnh | Có (hình dạng đầu/mặt), nhưng độ phân giải hàng ghế sau thường nhỏ |
| 7 | `frame_meta` (`modality`, `light`, `camera_blocked`) | `rgb`/`ir` · `day`/`night`/`unknown` · `yes`/`no` | Gắn metadata chất lượng khung hình để lọc dữ liệu train/eval và phát hiện camera bị che | Áp dụng cho cả RGB và IR (phát hiện che ống kính, điều kiện sáng) |

## 2 câu hỏi leo thang

1. Câu hỏi: Khi một ghế trẻ em (`child_seat`) hoặc nôi em bé (`infant_seat`) có hình dạng trên ảnh IR khó phân biệt giữa hai loại, hoặc trong ghế trẻ em có đặt đồ vật/búp bê, guideline xử lý thuộc tính `occupied` (`yes` vs `no` + box `object` riêng) như thế nào để tránh gán mâu thuẫn?
   Khung ví dụ: `S02_rgb.png` và `S02_ir.png` (ghế `rear_right` gán `infant_seat` trên RGB nhưng dễ nhầm sang `child_seat` với `occupied=yes` trên IR-sim).
   Bạn tạm gán thế nào và vì sao: Tạm kiểm tra lại theo cấu trúc nôi xách trên `S02_rgb` để thống nhất `infant_seat` nếu đúng là nôi, và chỉ dùng `child_seat` khi là ghế trẻ em đứng; không suy đoán vượt quá hình dạng thấy được trên từng khung.
2. Câu hỏi: Khi khuôn mặt tài xế quay nghiêng mạnh khiến toàn bộ 4 điểm của một bên mắt bị `outside`/`occluded` (nhưng vẫn thấy thoáng một phần khóe hoặc gọng kính), ngưỡng nào bắt buộc phải chuyển `eye_left`/`eye_right` từ `open` sang `unknown`?
   Khung ví dụ: `D04.png` (có `face13` với 8 điểm `outside` và 1 điểm `occluded`, dẫn đến cảnh báo `cabin_check` về mâu thuẫn `eye_left=open`/`eye_right=open`).
   Bạn tạm gán thế nào và vì sao: Tạm chuyển `eye_left`/`eye_right` sang `unknown` cho bất kỳ mắt nào có cả 4 điểm `*_eye_*` bị `occluded`/`outside` theo đúng quy tắc 4.4-1 ("không thấy thì `unknown`").
