# Khai báo dùng AI — Mai Quang Khải

Nhắc lại: không đưa ảnh cabin hay ảnh tài xế (kể cả ảnh chụp màn hình) cho bất kỳ công cụ AI nào. *(Toàn bộ phiên làm việc chỉ dùng AI cho tài liệu, cấu hình CVAT local, chạy script `cabin_check.py` trên XML export và góp ý văn bản; tuyệt đối không gửi hay đọc bất kỳ file ảnh `.png` nào trong `G02/`.)*

| # | Công cụ | Bạn hỏi gì (tóm tắt) | Bạn dùng kết quả thế nào | Bạn có kiểm lại không? Bằng gì? |
|---|---|---|---|---|
| 1 | Antigravity (Gemini 4 Hydrogen) | Phân tích cấu trúc repo, `README.md`, `GUIDE.md`, `RULES.md` và lập kế hoạch làm Lab Ngày 12 cho bộ `G02` | Dùng để nắm đúng quy trình Task 0–4, quy tắc ghế theo xe, quy tắc `D##` xoay 90° và danh sách file nộp E1–E5 | Có, đối chiếu trực tiếp với `GUIDE.md`, `CHECKPOINTS.md` và `SUBMISSION.md` |
| 2 | Antigravity + `cvat-mcp` | Tạo project `Day12`, task `Day12-G02` trên CVAT local (`127.0.0.1:8080`), cập nhật thêm `occupied=yes` cho nhãn `child_seat` và export `export_final.zip` (không ảnh) | Tự động hóa thao tác cấu hình project/nhãn và export XML mà không làm mất annotation đang gán | Có, kiểm tra số lượng tags/shapes trước-sau trên CVAT và kiểm tra `zipfile -l export_final.zip` chỉ có `annotations.xml` |
| 3 | Antigravity | Cập nhật `scripts/cabin_schema.py` cho khớp JSON nhãn mới (`child_seat.occupied` thêm `yes`) và chạy `cabin_check.py` cho `check_cpA.txt`, `check_cpB.txt`, `check_final.txt` | Kiểm tra lỗi/cảnh báo tự động trên 22 ảnh đã tự gán nhãn trên CVAT | Có, đọc trực tiếp output của `cabin_check.py` và rà lại trên CVAT các cảnh báo ở `S01–S08`, `D01`, `D04` |
| 4 | Antigravity | Góp ý hoàn thiện câu chữ cho `class_list_v0.md`, tổng hợp khung `ir_log.csv` từ metadata `annotations.xml`, và đối chiếu đáp án `exit_ticket.md` | Dùng làm bản nháp hoàn chỉnh cho E4, E5 và rà soát tính toán `exit_ticket.md` | Có, tự đối chiếu lại từng dòng `ir_log.csv` với ảnh thật trên CVAT local và kiểm tra lại công thức `exit_ticket.md` |
