# Tự đánh giá — Mai Quang Khải · G02

## 1. Tự rà soát 4 cảnh

Nghỉ tay 1 phút, mở lại bài của mình, chọn 4 ảnh (2 S##, 2 D##), đọc như người lạ.

Loại lỗi: `seat_flip`, `wrong_class`, `guess`, `box`, `missing`, `extra`, `lr_flip` (trái/phải mặt), `flag` (thiếu cờ điểm), `ok`.

| Ảnh | Đối tượng | Loại lỗi | Ghi chú | Đã sửa? |
|---|---|---|---|---|
| `S01_rgb.png` | `infant_seat` (trước đó gán `object`) | `wrong_class` | Nhầm nôi xách em bé thành `object` ở bản v1, sau review chéo đã đổi sang `infant_seat` | Đã sửa (v2) |
| `S02_ir.png` | `infant_seat` | `ok` | Khớp loại `infant_seat` (`facing=rear`) và vị trí ghế `rear_right` với `S02_rgb.png` | Đã khớp (v2) |
| `D01.png` | `face` & `face13` (`eye_left` / `occluded`) | `flag` | Ban đầu để `eye_left=unknown` nhưng thiếu/nhầm bên cờ `occluded` trên `left_eye_*` do ảnh xoay 90° | Đã sửa (v2) |
| `D04.png` | `face` (`eye_left`, `eye_right`) | `guess` | Để `open` trong khi cả 4 điểm mắt mỗi bên đều `outside`; đã đối chiếu và sửa đúng theo quy tắc `unknown` | Đã sửa (v2) |

## 2. Lỗi mình lặp lại nhiều nhất hôm nay

Lỗi: Gán nhầm trạng thái mắt (`open`/`unknown`) không đồng bộ với cờ `occluded`/`outside` của cụm `face13` (và nhầm trái/phải mắt trên ảnh `D##` xoay 90°).

Vì sao mình mắc: Ảnh `D##` bị xoay 90° làm phản xạ nhìn màn hình dễ nhầm mắt trái/mắt phải của tài xế, và khi thấy thoáng vùng mắt qua kính vẫn có xu hướng đoán `open` thay vì giữ `unknown` khi các điểm `face13` đã bị che/ra ngoài.

Lần sau tránh bằng cách: Luôn kiểm tra tọa độ `y` trên ảnh xoay 90° (`left_eye_*` có `y` lớn hơn), gắn cờ `occluded`/`outside` cho từng điểm `face13` trước rồi mới chốt `eye_left`/`eye_right` trên `face`, và chạy `cabin_check.py` ngay sau mỗi chặng.

## 3. Ghi chú về disagreement_log

Một dòng bạn của mình đúng và mình sai. Mình học được gì từ dòng đó: Ở `D04.png` (`face.eye_left` và `face.eye_right`), mình ghi `open` trong khi bạn ghi `unknown`. Khi kiểm lại `face13` thấy cả 4 điểm mỗi mắt đều `outside=1` — bạn đã tuân thủ chặt quy tắc 4.4-1 ("không thấy thì `unknown`, không đoán"), giúp mình sửa kịp thời ở `export_final_v2.zip` để đạt `0 lỗi, 0 cảnh báo`.
